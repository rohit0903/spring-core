package com.rohit.spring.service;

import org.joda.time.LocalDate;

public interface DateService {

	LocalDate getNextAssessmentDate();
}
